import { ProjectOverview } from "@/components/project-overview/ProjectOverview";
import { getProject } from "@/application/queries/getProject";
import { InMemoryProjectRepository } from "@/infrastructure/repositories/InMemoryProjectRepository";

const projects = [
  {
    id: "project-1",
    name: "Acme Commerce",
    latestAudit: null,
  },
];

const repository = new InMemoryProjectRepository(projects);

type ProjectPageProps = {
  params: Promise<{
    projectId: string;
  }>;
};

export default async function ProjectPage({ params }: ProjectPageProps) {
  const { projectId } = await params;
  const result = await getProject(repository, projectId);

  if (result.status === "not-found") {
    return <ProjectOverview project={null} />;
  }

  return <ProjectOverview project={result.project} />;
}
